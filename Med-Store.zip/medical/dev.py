# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ["*"]

EMAIL_HOST_USER = DEFAULT_FROM_EMAIL = ''              # email
EMAIL_HOST_PASSWORD = ''                                         # Gmail_password

# CORS HEADERS
CORS_ORIGIN_ALLOW_ALL = True
CORS_ALLOW_CREDENTIALS = True
