from django.apps import AppConfig


class MedicinesConfig(AppConfig):
    name = 'medicines'
