# A little bit modification, used the __init__.py as to make different routes in different files
from .medicine import *
from .auth import *
from .cart import *
from .order import *
from .checkout import *
